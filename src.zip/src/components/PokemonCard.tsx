import { useEffect, useState } from "react";
import { PokemonDetail } from "../types/pokemon";

interface PokemonCardProps {
  name: string;
  isSelected: boolean;
  onSelect: (name: string) => void;
}

export default function PokemonCard({ name, isSelected, onSelect }: PokemonCardProps) {
  const [detail, setDetail] = useState<PokemonDetail | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchDetail = async () => {
      try {
        const res = await fetch(`https://pokeapi.co/api/v2/pokemon/${name}`);
        const data: PokemonDetail = await res.json();
        setDetail(data);
      } finally {
        setLoading(false);
      }
    };

    fetchDetail();
  }, [name]);

  if (loading) {
    return <div className="bg-gray-300 animate-pulse h-40 rounded"></div>;
  }

  return (
    <div
      onClick={() => onSelect(name)}
      className={`p-4 rounded border cursor-pointer ${
        isSelected ? "border-blue-500 scale-105" : "border-gray-300"
      }`}
    >
      <h2 className="text-center capitalize">{name}</h2>

      {detail?.sprites.front_default && (
        <img src={detail.sprites.front_default} alt={name} className="mx-auto" />
      )}

      <div className="flex justify-center gap-2 mt-2">
        {detail?.types.map((t) => (
          <span key={t.slot} className="bg-gray-200 px-2 rounded text-sm">
            {t.type.name}
          </span>
        ))}
      </div>

      {isSelected && (
        <ul className="mt-2 text-sm">
          {detail?.stats.map((s) => (
            <li key={s.stat.name}>
              {s.stat.name}: {s.base_stat}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}