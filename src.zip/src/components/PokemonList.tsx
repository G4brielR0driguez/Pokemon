import PokemonCard from "./PokemonCard";
import { PokemonListItem } from "../types/pokemon";

interface PokemonListProps {
  pokemons: PokemonListItem[];
  selected: string | null;
  onSelect: (name: string) => void;
}

export default function PokemonList({ pokemons, selected, onSelect }: PokemonListProps) {
  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      {pokemons.map((pokemon) => (
        <PokemonCard
          key={pokemon.name}
          name={pokemon.name}
          isSelected={selected === pokemon.name}
          onSelect={onSelect}
        />
      ))}
    </div>
  );
}   